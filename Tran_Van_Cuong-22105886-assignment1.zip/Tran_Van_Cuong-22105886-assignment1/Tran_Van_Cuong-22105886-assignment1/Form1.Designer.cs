﻿namespace Tran_Van_Cuong_22105886_assignment1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnl_menu = new System.Windows.Forms.Panel();
            this.btn_on_red = new System.Windows.Forms.Button();
            this.btn_on_green = new System.Windows.Forms.Button();
            this.btn_on_yellow = new System.Windows.Forms.Button();
            this.btn_off_yellow = new System.Windows.Forms.Button();
            this.btn_off_green = new System.Windows.Forms.Button();
            this.btn_off_red = new System.Windows.Forms.Button();
            this.pnl_red = new System.Windows.Forms.Panel();
            this.pnl_green = new System.Windows.Forms.Panel();
            this.pnl_yellow = new System.Windows.Forms.Panel();
            this.pnl_settings = new System.Windows.Forms.Button();
            this.pnl_Start = new System.Windows.Forms.Button();
            this.pnl_finish = new System.Windows.Forms.Button();
            this.dtp_dateandtime = new System.Windows.Forms.DateTimePicker();
            this.pnl_menu.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_menu
            // 
            this.pnl_menu.BackColor = System.Drawing.SystemColors.WindowText;
            this.pnl_menu.Controls.Add(this.pnl_yellow);
            this.pnl_menu.Controls.Add(this.pnl_red);
            this.pnl_menu.Controls.Add(this.pnl_green);
            this.pnl_menu.Location = new System.Drawing.Point(23, 12);
            this.pnl_menu.Name = "pnl_menu";
            this.pnl_menu.Size = new System.Drawing.Size(308, 524);
            this.pnl_menu.TabIndex = 0;
            // 
            // btn_on_red
            // 
            this.btn_on_red.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_on_red.Location = new System.Drawing.Point(337, 109);
            this.btn_on_red.Name = "btn_on_red";
            this.btn_on_red.Size = new System.Drawing.Size(75, 23);
            this.btn_on_red.TabIndex = 1;
            this.btn_on_red.Text = "ON";
            this.btn_on_red.UseVisualStyleBackColor = true;
            // 
            // btn_on_green
            // 
            this.btn_on_green.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_on_green.Location = new System.Drawing.Point(337, 236);
            this.btn_on_green.Name = "btn_on_green";
            this.btn_on_green.Size = new System.Drawing.Size(75, 23);
            this.btn_on_green.TabIndex = 1;
            this.btn_on_green.Text = "ON";
            this.btn_on_green.UseVisualStyleBackColor = true;
            this.btn_on_green.Click += new System.EventHandler(this.btn_on_green_Click);
            // 
            // btn_on_yellow
            // 
            this.btn_on_yellow.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_on_yellow.Location = new System.Drawing.Point(337, 400);
            this.btn_on_yellow.Name = "btn_on_yellow";
            this.btn_on_yellow.Size = new System.Drawing.Size(75, 23);
            this.btn_on_yellow.TabIndex = 1;
            this.btn_on_yellow.Text = "ON";
            this.btn_on_yellow.UseVisualStyleBackColor = true;
            this.btn_on_yellow.Click += new System.EventHandler(this.btn_on_yellow_Click);
            // 
            // btn_off_yellow
            // 
            this.btn_off_yellow.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_off_yellow.Location = new System.Drawing.Point(337, 457);
            this.btn_off_yellow.Name = "btn_off_yellow";
            this.btn_off_yellow.Size = new System.Drawing.Size(75, 23);
            this.btn_off_yellow.TabIndex = 1;
            this.btn_off_yellow.Text = "OFF";
            this.btn_off_yellow.UseVisualStyleBackColor = true;
            // 
            // btn_off_green
            // 
            this.btn_off_green.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_off_green.Location = new System.Drawing.Point(337, 294);
            this.btn_off_green.Name = "btn_off_green";
            this.btn_off_green.Size = new System.Drawing.Size(75, 23);
            this.btn_off_green.TabIndex = 1;
            this.btn_off_green.Text = "OFF";
            this.btn_off_green.UseVisualStyleBackColor = true;
            // 
            // btn_off_red
            // 
            this.btn_off_red.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_off_red.Location = new System.Drawing.Point(337, 157);
            this.btn_off_red.Name = "btn_off_red";
            this.btn_off_red.Size = new System.Drawing.Size(75, 23);
            this.btn_off_red.TabIndex = 1;
            this.btn_off_red.Text = "OFF";
            this.btn_off_red.UseVisualStyleBackColor = true;
            // 
            // pnl_red
            // 
            this.pnl_red.BackColor = System.Drawing.Color.Red;
            this.pnl_red.Location = new System.Drawing.Point(49, 83);
            this.pnl_red.Name = "pnl_red";
            this.pnl_red.Size = new System.Drawing.Size(200, 100);
            this.pnl_red.TabIndex = 2;
            // 
            // pnl_green
            // 
            this.pnl_green.BackColor = System.Drawing.Color.LimeGreen;
            this.pnl_green.Location = new System.Drawing.Point(49, 224);
            this.pnl_green.Name = "pnl_green";
            this.pnl_green.Size = new System.Drawing.Size(200, 100);
            this.pnl_green.TabIndex = 3;
            // 
            // pnl_yellow
            // 
            this.pnl_yellow.BackColor = System.Drawing.Color.Yellow;
            this.pnl_yellow.Location = new System.Drawing.Point(49, 388);
            this.pnl_yellow.Name = "pnl_yellow";
            this.pnl_yellow.Size = new System.Drawing.Size(200, 100);
            this.pnl_yellow.TabIndex = 3;
            // 
            // pnl_settings
            // 
            this.pnl_settings.Location = new System.Drawing.Point(900, 79);
            this.pnl_settings.Name = "pnl_settings";
            this.pnl_settings.Size = new System.Drawing.Size(106, 63);
            this.pnl_settings.TabIndex = 2;
            this.pnl_settings.Text = "Settings";
            this.pnl_settings.UseVisualStyleBackColor = true;
            // 
            // pnl_Start
            // 
            this.pnl_Start.Location = new System.Drawing.Point(1044, 79);
            this.pnl_Start.Name = "pnl_Start";
            this.pnl_Start.Size = new System.Drawing.Size(102, 63);
            this.pnl_Start.TabIndex = 3;
            this.pnl_Start.Text = "Start";
            this.pnl_Start.UseVisualStyleBackColor = true;
            // 
            // pnl_finish
            // 
            this.pnl_finish.Location = new System.Drawing.Point(1175, 79);
            this.pnl_finish.Name = "pnl_finish";
            this.pnl_finish.Size = new System.Drawing.Size(102, 63);
            this.pnl_finish.TabIndex = 4;
            this.pnl_finish.Text = "Finish";
            this.pnl_finish.UseVisualStyleBackColor = true;
            this.pnl_finish.Click += new System.EventHandler(this.pnl_finish_Click);
            // 
            // dtp_dateandtime
            // 
            this.dtp_dateandtime.Location = new System.Drawing.Point(900, 38);
            this.dtp_dateandtime.Name = "dtp_dateandtime";
            this.dtp_dateandtime.Size = new System.Drawing.Size(377, 20);
            this.dtp_dateandtime.TabIndex = 5;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1347, 627);
            this.Controls.Add(this.dtp_dateandtime);
            this.Controls.Add(this.pnl_finish);
            this.Controls.Add(this.pnl_Start);
            this.Controls.Add(this.pnl_settings);
            this.Controls.Add(this.btn_off_red);
            this.Controls.Add(this.btn_off_green);
            this.Controls.Add(this.btn_off_yellow);
            this.Controls.Add(this.btn_on_yellow);
            this.Controls.Add(this.btn_on_green);
            this.Controls.Add(this.btn_on_red);
            this.Controls.Add(this.pnl_menu);
            this.Name = "Form1";
            this.Text = "Form1";
            this.pnl_menu.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_menu;
        private System.Windows.Forms.Panel pnl_yellow;
        private System.Windows.Forms.Panel pnl_red;
        private System.Windows.Forms.Panel pnl_green;
        private System.Windows.Forms.Button btn_on_red;
        private System.Windows.Forms.Button btn_on_green;
        private System.Windows.Forms.Button btn_on_yellow;
        private System.Windows.Forms.Button btn_off_yellow;
        private System.Windows.Forms.Button btn_off_green;
        private System.Windows.Forms.Button btn_off_red;
        private System.Windows.Forms.Button pnl_settings;
        private System.Windows.Forms.Button pnl_Start;
        private System.Windows.Forms.Button pnl_finish;
        private System.Windows.Forms.DateTimePicker dtp_dateandtime;
    }
}

